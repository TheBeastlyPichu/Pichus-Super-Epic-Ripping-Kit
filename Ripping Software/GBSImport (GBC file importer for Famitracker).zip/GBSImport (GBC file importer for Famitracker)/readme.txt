Instructions:

Output files are located in the gbs's source directory. The rest should be obvious. ;)

Credits go to:

- jsr for famitracker
- blargg and kode54 for foo_gep
- rainwarrior for the import dialog
- The FUSE team for the Z80_regpair
- Warheart, jrlepage, Shywolf, B00daW, mega9man, Macromaniac, moviemovies1, Vinyl Scratch, Rozul_TheBlue and betasword for beta testing!
